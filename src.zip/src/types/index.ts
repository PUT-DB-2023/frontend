export type BaseEntity = {
    id: number;
    createdAt: number;
  };
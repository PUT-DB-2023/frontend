import React from 'react'

export const Error = () => {
  return (
    <h1 className='font-bold text-black self-center text-5xl justify-self-center'>Error</h1>
  )
}

import { BaseEntity } from "types";

export type User = {
    name: string;

} & BaseEntity;
import { ContentLayout } from 'components'
import React from 'react'

export const Course = () => {
  return (
    <ContentLayout title='Przedmiot - szczegóły'>
        <div className='flex w-full flex-wrap'>
        </div>
    </ContentLayout>
  )
}

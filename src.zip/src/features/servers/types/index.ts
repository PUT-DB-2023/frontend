import { BaseEntity } from "types";

export type Server = {
    name: string;

} & BaseEntity;
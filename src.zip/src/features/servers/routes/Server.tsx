import React from 'react'

export const Server = () => {
  return (
    <div>Server</div>
  )
}

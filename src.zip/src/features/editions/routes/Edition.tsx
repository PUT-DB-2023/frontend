import React from 'react'

export const Edition = () => {
  return (
    <div>Edition</div>
  )
}
